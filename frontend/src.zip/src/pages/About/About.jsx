import "./About.css";

export default function About() {
  return (
    <div className="about">
      <h1>Giới thiệu</h1>
      <p>Đây là trang giới thiệu website ngôn ngữ ký hiệu.</p>
    </div>
  );
}
