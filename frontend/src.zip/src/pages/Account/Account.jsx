export default function Account() {
  return (
    <div>
      <h2>Đăng nhập</h2>
      <input placeholder="Email" />
      <input placeholder="Password" type="password" />
      <button>Login</button>
    </div>
  );
}
